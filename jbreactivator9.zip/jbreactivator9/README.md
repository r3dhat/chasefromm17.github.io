# jailbreakreactivator9

JailbreakReactivator9!

**WARNING**: **JAILBREAKREACTIVATOR9 IS CURRENTLY IT'S EARLY BETA STAGE! DON'T HOLD ME ACCOUNTABLE IF THIS SOMEHOW MESSED UP AND FORCES YOU TO RESTORE IN ITUNES OR IF ANYTHING WRONG HAPPENS!**

JailbreakReactivator9 is just a website shortcut that is supposed to be used to reactivate your iOS 9.2-9.3.3 ARM64-bit jailbreak, no need for Julio's webclip on his repo or to use jbme.qwertyoruiop.com anymore. Tap on the 'enter jailbroken mode again" button, then wait for an alert to pop up to lock your iOS device and wait for it to re-enter in jailbroken mode!

To clarify: **NO**, this is **NOT A JAILBREAK**, it's a **loader**, so it's only if you jailbroke with the Pangu 9.3.3 jailbreak and rebooted the device into unjailbroken state.

This tool will help you regain your simple jailbreak functionality, and it's useful.
